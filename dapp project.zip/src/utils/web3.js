// src/utils/web3.js

import Web3 from 'web3';

const INFURA_URL = `https://mainnet.infura.io/v3/2056297d64174b6f8e246f40087c9b32`;

let web3;

if (window.ethereum) {
  // Modern dapp browsers...
  web3 = new Web3(window.ethereum);
  try {
    // Request account access if needed
    window.ethereum.request({ method: 'eth_requestAccounts' });
  } catch (error) {
    console.error("User denied account access");
  }
} else if (window.web3) {
  // Legacy dapp browsers...
  web3 = new Web3(window.web3.currentProvider);
} else {
  // Non-dapp browsers...
  web3 = new Web3(new Web3.providers.HttpProvider(INFURA_URL));
}

export default web3;
