// src/App.js

import React, { useEffect, useState } from 'react';
import web3 from './utils/web3';
import './App.css'; // Ensure you import your CSS for styling

function App() {
  const [account, setAccount] = useState('');
  const [balance, setBalance] = useState('');
  const [showBalance, setShowBalance] = useState(false); // State to toggle balance display

  // Load user account and balance
  useEffect(() => {
    async function loadBlockchainData() {
      const accounts = await web3.eth.getAccounts(); // Get user accounts

      if (accounts.length === 0) {
        console.error('No accounts found');
      } else {
        setAccount(accounts[0]);

        const balanceWei = await web3.eth.getBalance(accounts[0]); // Get balance in wei
        const balanceEth = web3.utils.fromWei(balanceWei, 'ether'); // Convert balance to ether
        setBalance(balanceEth);
      }
    }

    loadBlockchainData();
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to My DApp</h1>
        <button className="address-button" onClick={() => alert(`Account: ${account}`)}>
          {account ? `${account.slice(0, 5)}...${account.slice(-4)}` : 'Connect Wallet'}
        </button>
        <button className="balance-button" onClick={() => setShowBalance(!showBalance)}>
          {showBalance ? 'Hide Balance' : 'Show Balance'}
        </button>
        {showBalance && <p>Balance: {balance} ETH</p>}
      </header>
    </div>
  );
}

export default App;
